/*
 * KY-040.h
 *
 *  Created on: 1 paź 2022
 *      Author: novak
 */

#ifndef INC_KY040_H_
#define INC_KY040_H_
/*
#define CHANNEL_A 	HAL_GPIO_ReadPin(DT_GPIO_Port, DT_Pin)
#define CHANNEL_B	HAL_GPIO_ReadPin(CLK_GPIO_Port, CLK_Pin)
#define CHANNEL_SW	HAL_GPIO_ReadPin(SW_GPIO_Port,SW_Pin)
*/



#endif /* INC_KY040_H_ */
